#include <avr/io.h>
#include <util/delay.h>
#include "HeaderFiles/dwenguinoBoard.h"
#include "HeaderFiles/dwenguinoLCD.h"
#include "HeaderFiles/i2c.h"
#include <avr/interrupt.h>




ISR(TWI_vect) {


}
int main(void)
{
//scherm
initBoard();
initLCD();
backlightOn();
//EICRB |=_BV(PE1);
//EIMSK |=_BV(PE4);
SREG |= _BV(PE7);
DDRE |= _BV(PE4);
PORTE |=_BV(PE4);

//poorten en pull up acc
DDRD |= _BV(PD0);
DDRD |= _BV(PD1);
PORTD |=_BV(PD0);
PORTD |=_BV(PD1);


//startconditie


TWCR &= ~_BV(TWSTO);
TWCR &= ~_BV(TWSTA);

clearLCD();

//loadSLAR();

/*sendSTART();
loadSLAR();*/
//BYTE ball[8] = {0b11100,0b11100,0b11100,0};


//PORTF op output
//DDRF |=_BV(PF0);


startI2C();

int minx=0,maxx=0;
int miny=0, maxy=0;
int minz=0,maxz=0;

while(1){
  /*
  printIntToLCD(maxx,1,0);
  printIntToLCD(minx,0,0);
  printIntToLCD(maxy,1,5);
  printIntToLCD(miny,0,5);
  printIntToLCD(maxz,1,10);
  printIntToLCD(minz,0,10);


  printIntToLCD(readGyroX(),1,0);
  printIntToLCD(readAccelX(),0,0);
  printIntToLCD((readGyroY()),1,5);
  printIntToLCD(readAccelY(),0,5);
  printIntToLCD(readGyroZ(),1,10);
  printIntToLCD(readAccelZ(),0,10);

  if(maxx<readAccelX())maxx=readAccelX();
  if(minx>readAccelX())minx=readAccelX();
  if(maxy<readAccelY())maxy=readAccelY();
  if(miny>readAccelY())miny=readAccelY();
  if(maxz<readAccelZ())maxz=readAccelZ();
  if(minz>readAccelZ())minz=readAccelZ();
*/

  double  hoeken[3];
  hoeken[0]=(double)readAccelX();
  hoeken[1]=readAccelY();
  hoeken[3]=readAccelZ();



/*
  printIntToLCD((hoeken[0]),0,0);
  printIntToLCD(nrmlData(hoeken[1]),0,5);
  printIntToLCD(nrmlData(hoeken[2]),0,10);
*/
  //convToAngle(hoeken);

  printIntToLCD(hoeken[0],1,0);
  printIntToLCD(hoeken[1],1,5);
  //printIntToLCD(hoeken[2],1,10);


  printIntToLCD(giveDirection(hoeken[0], hoeken[1]),0,0);


  _delay_ms(150);
  clearLCD();


}






  return 0;
}
